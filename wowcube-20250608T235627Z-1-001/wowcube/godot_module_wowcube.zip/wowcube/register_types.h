#include "modules/register_module_types.h"

void initialize_wowcube_module(ModuleInitializationLevel p_level);
void uninitialize_wowcube_module(ModuleInitializationLevel p_level);